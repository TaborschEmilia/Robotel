#include "DriveMode.h"

/* instante a clasei L298N motor driver cu pinii de control ca parametri constructorului
pwm channel(0-16), pwm pin(ENA), pinIN1, pinIN2*/
L298N motor_stanga(0, 12, 14, 27);
L298N motor_dreapta(1, 26, 25, 33);

void Drive::incetineste(int viteza) //functia de mers incet inainte
{
    motor_stanga.setSpeed(viteza);
    motor_dreapta.setSpeed(viteza);
    motor_stanga.forward();
    motor_dreapta.forward();
}

void Drive::inainte(int viteza)
{
    motor_stanga.setSpeed(viteza);
    motor_dreapta.setSpeed(viteza);
    motor_stanga.forward();
    motor_dreapta.forward();
}

void Drive::inapoi(int viteza)
{
    motor_stanga.setSpeed(viteza);
    motor_dreapta.setSpeed(viteza);
    motor_stanga.backward();
    motor_dreapta.backward();
}

void Drive::vireazaStanga(int viteza_de_revenire, int motor_pause) //Viram la stanga cu definitie de timp
{
    motor_stanga.stop();
    motor_dreapta.forward();
    delay(motor_pause);
    motor_stanga.setSpeed(viteza_de_revenire);
    motor_stanga.forward();
}

void Drive::vireazaStanga(int viteza_de_rotatie) //opreste un motor pentru a vira la stanga
{
    motor_dreapta.setSpeed(viteza_de_rotatie);
    motor_stanga.stop();
    motor_dreapta.forward();
}

void Drive::vireazaDreapta(int viteza_de_revenire, int motor_pause) //opreste un motor pentru a vira la stanga
{
    motor_dreapta.stop();
    motor_stanga.forward();
    delay(motor_pause);
    motor_dreapta.setSpeed(viteza_de_revenire);
    motor_dreapta.forward();
}

void Drive::vireazaDreapta(int viteza_de_rotatie) //opreste un motor pentru a vira la stanga
{
    motor_stanga.setSpeed(viteza_de_rotatie);
    motor_dreapta.stop();
    motor_stanga.forward();
}

void Drive::stop()
{
    motor_stanga.stop();
    motor_dreapta.stop();
}

Drive::Drive() // constructor
{
    motor_stanga.init();
    motor_dreapta.init();
}

Drive::~Drive() // destructor
{
}