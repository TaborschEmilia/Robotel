
#include "L298N.h"

void ledcAnalogWrite(int p_channel, int p_value) 
{
  int duty = (8191 / 255) * min(p_value, 255);
  ledcWrite(p_channel, duty);
}

void L298N::init() // setup PWM channel and assign a pin to it
{
  ledcSetup(m_channel, LEDC_BASE_FREQ, LEDC_TIMER_13_BIT);
  ledcAttachPin(m_pinEnable, m_channel);
}

void L298N::setSpeed(int pwmVal) // set the pwm duty as speed
{
  m_pwmVal = pwmVal;
}

int L298N::getSpeed() // get the pwm duty as speed
{
  return m_pwmVal;
}

void L298N::forward()
{
  digitalWrite(m_pinIN1, HIGH);
  digitalWrite(m_pinIN2, LOW);

  ledcAnalogWrite(m_channel, m_pwmVal);
  //analogWrite(m_pinEnable, m_pwmVal);
}

void L298N::backward()
{
  digitalWrite(m_pinIN1, LOW);
  digitalWrite(m_pinIN2, HIGH);

  ledcAnalogWrite(m_channel, m_pwmVal);
  //analogWrite(m_pinEnable, m_pwmVal);
}

void L298N::stop()
{
  digitalWrite(m_pinIN1, LOW);
  digitalWrite(m_pinIN2, LOW);

  ledcAnalogWrite(m_channel, m_pwmVal);
  //analogWrite(m_pinEnable, 100);
}

// class Constructor with initializer list
L298N::L298N(int channel, int pinEnable, int pinIN1, int pinIN2) : m_channel(channel), m_pinEnable(pinEnable), m_pinIN1(pinIN1), m_pinIN2(pinIN2)
{
  m_pwmVal = 100; // pwm duty 0-255
  pinMode(m_pinEnable, OUTPUT); // set the ENA pin as output
  pinMode(m_pinIN1, OUTPUT); // set the IN1 pin as putput
  pinMode(m_pinIN2, OUTPUT);  // set the IN2 pin as putput
}

//class Destructor
L298N::~L298N()
{
}