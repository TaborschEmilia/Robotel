#include "Arduino.h"

// use 13 bit precision for LEDC timer
#define LEDC_TIMER_13_BIT 13
// use 5000 Hz as a LEDC base frequency
#define LEDC_BASE_FREQ 5000

class L298N
{
public:
  //class Constructor
  L298N(int channel, int pinEnable, int pinIN1, int pinIN2);
  //class Destructor
  ~L298N();
  void setSpeed(int pwmVal);
  int getSpeed();
  void forward();
  void backward();
  void run(int direction);
  void stop();
  void reset();
  void init();

private: // private members set on constructor initializer list
  int m_pinEnable;
  int m_pinIN1;
  int m_pinIN2;
  int m_pwmVal = 0;
  int m_channel;
};