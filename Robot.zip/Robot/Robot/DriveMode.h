#include "L298N.h"


class Drive
{
public:
    Drive();
    ~Drive();

void incetineste(int viteza);
void inainte(int viteza);
void inapoi(int viteza);
void stop();
void vireazaDreapta(int viteza_de_revenire, int motor_pause);
void vireazaStanga(int viteza_de_revenire, int motor_pause);
void vireazaDreapta(int viteza_de_rotatie);
void vireazaStanga(int viteza_de_rotatie);
private:
};